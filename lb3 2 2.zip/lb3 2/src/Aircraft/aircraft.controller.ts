import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Post,
  Put,
} from '@nestjs/common';
import { ApiOperation, ApiTags } from '@nestjs/swagger';

import { AircraftServise } from './aircraft.service';
import { Aircraft } from './aircraft.entiti';
@Controller('aircraft')
@ApiTags ('Aircrafts')
export class AircraftController {
  constructor(private readonly aircraftServise: AircraftServise) {}
  @Get()
  findAll() {
    return this.aircraftServise.findAll();
  }

  @Put(':id')
  update(@Param('id') id: string, @Body() updateAircraft: Aircraft) {
    return this.aircraftServise.update(+id, updateAircraft);
  }
  @Post()
  create(@Body() createAircraft: Aircraft) {
    return this.aircraftServise.create(createAircraft);
  }
  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.aircraftServise.remove(+id);
  }
}
