export class Aircraft {
  id: number;
  registration_number: string;
  model: string;
  class: string;
  type: string;


}
