import { Module } from '@nestjs/common';
import { AircraftServise } from './aircraft.service';
import { AircraftController } from './aircraft.controller';
import { DatasourceModule } from 'src/Datasource /datasource.module';

@Module({
  controllers: [AircraftController],
  providers: [AircraftServise],
  imports: [DatasourceModule],
})
export class AircraftModel {}
