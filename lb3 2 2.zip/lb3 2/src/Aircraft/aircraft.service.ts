import { HttpStatus, Injectable } from '@nestjs/common';
import { DatasourceService } from '../Datasource /datasource.service';
import { Aircraft } from './aircraft.entiti';

@Injectable()
export class AircraftServise {
  constructor(private readonly datasourceService: DatasourceService) {}
 
  // добавление записи 
  create(aircraft: Aircraft) {
    this.datasourceService.getAircraft().push(aircraft);
    return aircraft;
  }
  //поиск записи
  findOne(model: string) {
   return this.datasourceService
     .getAircraft()
     .find((aircraft) => aircraft.model === model);
  }
  //возвращает все самолёты 
  findAll(): Aircraft[] {
    return this.datasourceService.getAircraft();
  }
  //изменение данных самолёта
  update(id: number, updateAircraft: Aircraft) {
    const index = this.datasourceService
      .getAircraft()
      .findIndex((aircraft) => aircraft.id === id);
    this.datasourceService.getAircraft()[index] = updateAircraft;
    return this.datasourceService.getAircraft()[index];
  }
  //Удаление самолёты
  remove(id: number) {
    const index = this.datasourceService
      .getAircraft()
      .findIndex((aircraft) => aircraft.id === id);
    this.datasourceService.getAircraft().splice(index, 1);
    return HttpStatus.OK;
  }
}
