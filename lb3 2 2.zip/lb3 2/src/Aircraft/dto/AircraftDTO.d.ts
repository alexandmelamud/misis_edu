export declare class CreateAircraftDto {
    fullname: string;
    type: string;
    post: string;
}
