export declare class IncompleteAircraftDto {
    id: number;
    fullName: string;
    post: string;
}
