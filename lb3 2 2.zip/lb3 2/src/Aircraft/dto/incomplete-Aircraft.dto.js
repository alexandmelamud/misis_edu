"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.IncompleteAircraftDto = void 0;
class IncompleteAircraftDto {
}
exports.IncompleteAircraftDto = IncompleteAircraftDto;
//# sourceMappingURL=incomplete-Aircraft.dto.js.map