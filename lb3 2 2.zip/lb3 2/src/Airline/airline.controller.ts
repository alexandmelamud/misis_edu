import {
  // eslint-disable-next-line prettier/prettier
    Body,
  Controller,
  Delete,
  Get,
  Param,
  Post,
  Put,
} from '@nestjs/common';
import { ApiOperation, ApiTags } from '@nestjs/swagger';
import { AirlinesServise } from './airline.service';
import { Airline } from './airline.entiti';
@Controller('airline')
@ApiTags ('Airline')
export class AirlinesController {
  constructor(private readonly airlinesServise: AirlinesServise) {}
  @Get()
  findAll() {
    return this.airlinesServise.findAll();
  }
  @Get(':Country')
  findOne(@Param('Country') Country: string) {
    return this.airlinesServise.findOne(Country);
  }
  @Put(':id')
  update(@Param('id') id: string, @Body() updateAirline: Airline) {
    return this.airlinesServise.update(+id, updateAirline);
  }
  @Post()
  create(@Body() createAirline: Airline) {
    return this.airlinesServise.create(createAirline);
  }
  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.airlinesServise.remove(+id);
  }
}
