export class Airline {
  id: number;
  Country: string;
  Number_of_aircrafts: number;
  phone: string;
  website: string;
}
