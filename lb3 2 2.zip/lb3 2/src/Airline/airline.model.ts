import { Module } from '@nestjs/common';
import { AirlinesServise } from './airline.service';
import { AirlinesController } from './airline.controller';
import { DatasourceModule } from 'src/Datasource /datasource.module';

@Module({
  controllers: [AirlinesController],
  providers: [AirlinesServise],
  imports: [DatasourceModule],
})
export class AirlineModel {}
