import { HttpStatus, Injectable } from '@nestjs/common';
import { DatasourceService } from '../Datasource /datasource.service';
import { Airline } from './airline.entiti';

@Injectable()
export class AirlinesServise {
  constructor(private readonly datasourceService: DatasourceService) {}
 
  // добавление авиакомпании
  create(airline: Airline) {
    this.datasourceService.getAirlines().push(airline);
    return airline;
  }
  //поиск авикомпании по стране.
  findOne(Country: string) {
    return this.datasourceService
      .getAirlines()
      .find((airline) => airline.Country === Country);
  }
  //возвращает всех авиакомпании.
  findAll(): Airline[] {
    return this.datasourceService.getAirlines();
  }
  //изменение данных авиакомпании.
  update(id: number, updateAirline: Airline) {
    const index = this.datasourceService
      .getAirlines()
      .findIndex((airline) => airline.id === id);
    this.datasourceService.getAirlines()[index] = updateAirline;
    return this.datasourceService.getAirlines()[index];
  }
  //Удаление данных авиакомпании
  remove(id: number) {
    const index = this.datasourceService
      .getAirlines()
      .findIndex((airline) => airline.id === id);
    this.datasourceService.getAirlines().splice(index, 1);
    return HttpStatus.OK;
  }
}
