export declare class CreateairlineDto {
    fullname: string;
    type: string;
    post: string;
}
