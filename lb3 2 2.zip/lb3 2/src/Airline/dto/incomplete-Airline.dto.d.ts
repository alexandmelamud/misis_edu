export declare class IncompleteairlineDto {
    id: number;
    fullName: string;
    post: string;
}
