"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.IncompleteairlineDto = void 0;
class IncompleteairlineDto {
}
exports.IncompleteairlineDto = IncompleteairlineDto;
//# sourceMappingURL=incomplete-airline.dto.js.map