import { Injectable } from '@nestjs/common';
import { Airline } from 'src/Airline/airline.entiti';
import { Passanger } from 'src/Passanger/passanger.entity';
import { Aircraft } from 'src/Aircraft/aircraft.entiti';

@Injectable()
export class DatasourceService {

  private aircraft: Aircraft[] = [];
  private airline: Airline[] = [];
  private passanger: Passanger[] = [];

  getAirlines(): Airline[] {
    return this.airline;
  }
  getPassangers(): Passanger[] {
    return this.passanger;
  }
  getAircraft(): Aircraft[] {
    return this.aircraft;
  }
}
