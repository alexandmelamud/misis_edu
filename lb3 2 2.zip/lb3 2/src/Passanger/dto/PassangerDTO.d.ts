export declare class CreatePassangerDto {
    fullname: string;
    type: string;
    post: string;
}
