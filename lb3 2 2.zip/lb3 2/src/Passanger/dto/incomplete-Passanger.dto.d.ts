export declare class IncompletePassangerDto {
    id: number;
    fullName: string;
    post: string;
}
