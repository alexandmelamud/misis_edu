"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.IncompletePassangerDto = void 0;
class IncompletePassangerDto {
}
exports.IncompletePassangerDto = IncompletePassangerDto;
//# sourceMappingURL=incomplete-Passanger.dto.js.map