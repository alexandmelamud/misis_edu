import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Post,
  Put,
} from '@nestjs/common';
import { ApiOperation, ApiTags } from '@nestjs/swagger';
import { PassangersServise } from './passanger.service';
import { Passanger } from './passanger.entity';
@Controller('Passanger')
@ApiTags('Passanger')
export class PassangerController {
  constructor(private readonly PassangerServise: PassangersServise) {}
  @Get()
  findAll() {
    return this.PassangerServise.findAll();
  }
  @Get(':passport')
  findOne(@Param('passport') passport: number) {
    return this.PassangerServise.findOne(+passport);
  }
  @Put(':id')
  update(@Param('id') id: string, @Body() updatePassanger: Passanger) {
    return this.PassangerServise.update(+id, updatePassanger);
  }
  @Post()
  create(@Body() createDoctor: Passanger) {
    return this.PassangerServise.create(createDoctor);
  }
  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.PassangerServise.remove(+id);
  }
}
