export class Passanger {
  id: number;
  fullname: string;
  age: number;
  passport: number;
  
}
