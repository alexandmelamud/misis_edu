import { Module } from '@nestjs/common';
import { PassangersServise } from './passanger.service';
import { PassangerController } from './passanger.controller';
import { DatasourceModule } from 'src/Datasource /datasource.module';

@Module({
  controllers: [PassangerController],
  providers: [PassangersServise],
  imports: [DatasourceModule],
})
export class PassangerModel {}
