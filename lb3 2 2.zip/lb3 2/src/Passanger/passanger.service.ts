import { HttpStatus, Injectable } from '@nestjs/common';
import { DatasourceService } from '../Datasource /datasource.service';
import { Passanger } from './passanger.entity';

@Injectable()
export class PassangersServise {
  constructor(private readonly datasourceService: DatasourceService) {}
  
  // добавление пассажира в бд.
  create(passanger: Passanger) {
    this.datasourceService.getPassangers().push(passanger);
    return passanger;
  }
  //поиск пассажира по номеру паспорта.
  findOne(passport: number) {
    return this.datasourceService
      .getPassangers()
      .find((passanger) => passanger.passport === passport);
  }
  //возвращает всех пассажиров.
  findAll(): Passanger[] {
    return this.datasourceService.getPassangers();
  }
  //изменение данных пассажира.
  update(id: number, updatePassanger: Passanger) {
    const index = this.datasourceService
      .getPassangers()
      .findIndex((Passanger) => Passanger.id === id);
    this.datasourceService.getPassangers()[index] = updatePassanger;
    return this.datasourceService.getPassangers()[index];
  }
  //Удаление данных пассажира
  remove(id: number) {
    const index = this.datasourceService
      .getPassangers()
      .findIndex((passanger) => passanger.id === id);
    this.datasourceService.getPassangers().splice(index, 1);
    return HttpStatus.OK;
  }
}
