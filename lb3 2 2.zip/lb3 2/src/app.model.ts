import { Module } from '@nestjs/common';

import { DatasourceModule } from './Datasource /datasource.module';
import { PassangerModel } from './Passanger/passanger.model';
import { AirlineModel } from './Airline/airline.model';
import { AircraftModel } from './Aircraft/aircraft.model';

@Module({
  imports: [ AircraftModel,AirlineModel,PassangerModel,DatasourceModule],
  controllers: [],
  providers: [],
})
export class AppModule {}
